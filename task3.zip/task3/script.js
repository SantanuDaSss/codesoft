let displayValue = "";

function appendToDisplay(value) {
    displayValue += value;
    document.getElementById("displayInput").value = displayValue;
}

function clearDisplay() {
    displayValue = "";
    document.getElementById("displayInput").value = "";
}

function calculate() {
    try {
        const result = eval(displayValue);
        document.getElementById("displayInput").value = result;
        displayValue = result.toString();
    } catch (error) {
        document.getElementById("displayInput").value = "Error";
        displayValue = "";
    }
}
